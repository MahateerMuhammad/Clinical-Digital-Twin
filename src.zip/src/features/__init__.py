"""Feature engineering sub-package."""
